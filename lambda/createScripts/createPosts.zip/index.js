exports.handler = async (event, context, cb) => {
    const { Client } = require('pg');
    const client = new Client({
                     user: "postgres",
                     host: "posts.crixemfe0mza.us-east-2.rds.amazonaws.com",
                     database: "posts",
                     password: "cmpt474dev",
                     port: 5432
                   });
    await client.connect();
    await client.query(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp";`);
    await client.query(`CREATE TABLE posts(
        id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
        sortingid SERIAL,
        dateTime TIMESTAMPTZ NOT NULL,
        title VARCHAR(200) NOT NULL,
        content TEXT,
        location VARCHAR(200),
        imageurl VARCHAR(200),
        numoflikes INTEGER DEFAULT 0 NOT NULL,
        numofcomments INTEGER DEFAULT 0 NOT NULL,
        authorname VARCHAR(200),
        tags TEXT[],
        userid uuid NOT NULL
    );`);
    // Your other interactions with RDS...
    client.end();
  };