const { Pool } = require('pg');

exports.handler = async (event, context) => {
  // Define your PostgreSQL database credentials
  const dbConfig = {
    user: "postgres",
    host: "posts.crixemfe0mza.us-east-2.rds.amazonaws.com",
    database: "posts",
    password: "cmpt474dev",
    port: 5432
  };

  // Create a connection pool to the PostgreSQL database
  const pool = new Pool(dbConfig);

  try {
    // Use a transaction to execute multiple SQL queries together
    await pool.query('BEGIN');
    const { location, imageUrl, content, title, tags } = JSON.parse(event['body']);
    const { userId } = event['pathParameters'];
    // const { username: authorname } = data.user;
    const res = await pool.query(
      "INSERT INTO posts (dateTime, title, location, imageUrl, userId, content, tags) VALUES (to_timestamp($1),$2,$3,$4,$5,$6,$7) RETURNING *",
      [
        Date.now() / 1000.0,
        title,
        location,
        imageUrl,
        userId,
        content,
        // authorname,
        tags,
      ]
    );
    let result = res.rows[0];

    // Commit the transaction to save the changes to the database
    await pool.query('COMMIT');

    // Return the result as a JSON response
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(result)
    };
  } catch (error) {
    // Roll back the transaction if an error occurs
    await pool.query('ROLLBACK');

    // Return the error message as a JSON response
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  } finally {
    // Release the client from the connection pool
    pool.end();
  }
};
