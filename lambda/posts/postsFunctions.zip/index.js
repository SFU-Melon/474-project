const { Pool } = require('pg');

exports.handler = async (event, context) => {
  let dbConfig;
  if (event["httpMethod"==="GET"]){
    // Define your PostgreSQL database credentials
    dbConfig = {
      user: process.env.user,
      host: process.env.read,
      database: process.env.database,
      password: process.env.password,
      port: process.env.port
    };
  }
  else {
    dbConfig = {
        user: process.env.user,
        host: process.env.write,
        database: process.env.database,
        password: process.env.password,
        port: process.env.port
    }
  }
  // Create a connection pool to the PostgreSQL database
  const pool = new Pool(dbConfig);

  try {
    // Use a transaction to execute multiple SQL queries together
    await pool.query('BEGIN');
    let result;

    // get all posts with filter and sort
    if (event["httpMethod"]==="GET" && event["path"].includes("getPosts")){
      const {
        filterType,
        val = undefined,
        sortingId = undefined,
        tags = undefined,
      } = event["queryStringParameters"];
      let userId = undefined; // modify when you can identify the logged in user
      // Initializing orderPart
      let orderByPart = "";
      if (filterType === "hot") {
        orderByPart = `ORDER BY numoflikes DESC, sortingid ASC`;
      } else {
        orderByPart = `ORDER By datetime DESC, sortingid ASC`;
      }

      // Initializing wherePart
      let wherePart = "";
      if (val !== undefined) {
        //When it's not the first time it fetches posts -> lastElement data is null. -> wherePart=""
        wherePart = `WHERE ${
          filterType === "hot"
            ? `((numoflikes < ${val}) OR (numoflikes = ${val} AND sortingid > ${sortingId}))`
            : `datetime <  (select '${val}'::timestamptz) `
        }`;
      }

      if (tags !== undefined) {
        let subQuery = "SELECT name from tags WHERE";
        tags.forEach((tag, i) => {
          subQuery += `${i === 0 ? "" : " OR"} name = '${tag}'`;
        });
        wherePart += `${val !== undefined ? " AND" : "WHERE"} NOT EXISTS ( 
          SELECT name FROM (${subQuery}) as SUB 
          WHERE name NOT IN (
            SELECT UNNEST(tags) from posts where id = p.id
          )
        )`;
      }

      //If the user exists (logged in)
      if (userId != undefined) {
        const res = await pool.query(
          `SELECT id, dateTime, title, content, numofcomments, location, imageUrl, numOfLikes, authorname, sortingid, likes.val, tags
          FROM posts p
          LEFT JOIN likes ON p.id = likes.postId AND likes.userId = $1
          ${wherePart}
          ${orderByPart}
          LIMIT 6`,
          [userId]
        );
        result = res.rows;
      }
      else {
        //If the user doesn't exist
        const res = await pool.query(
          `SELECT * FROM posts p
          ${wherePart}
          ${orderByPart}
          LIMIT 6`
        );
        result = res.rows;
      }
    }

    // get post by id
    else if (event["httpMethod"]==="GET" && event["pathParameters"]["postId"]){
      const { postId } = event["pathParameters"];
      const res = await pool.query("SELECT * FROM posts WHERE id = $1", [postId]);
      result = res.rows[0];
    }

    // get post liked not owned
    else if (event["httpMethod"]==="GET" && event["path"].includes("getPostLikedNotOwned")){
      const { userId } = event["pathParameters"];
      const res = await pool.query(
        "SELECT * FROM likes L, posts P WHERE L.userid = $1 AND L.userid <> P.userid AND P.id = L.postid AND L.val = 1",
        [userId]
      );
      result = res.rows;
    }

    // get all posts by a user
    else if (event["httpMethod"]==="GET" && event["path"].includes("getAllPosts")){
      const { userId } = event["pathParameters"];
      const res = await pool.query(
        "SELECT * FROM posts WHERE userId = $1 ORDER BY datetime DESC",
        [userId]
      );
      result = res.rows;
    }
    // edit post
    else if (event["httpMethod"]==="POST" && event["path"].includes("editPost")){
      const { userId } = event["pathParameters"];
      const { postId, title, content, location, tags } = JSON.parse(event['body']);
      if (userId && postId && title) {
        const res = await pool.query(
          `UPDATE posts 
          SET title = $1, content = $2, location = $3, tags = $4
          WHERE id = $5 AND userid = $6`,
          [title, content, location, tags, postId, userId]
        );
  
        result = res.rows[0];
      }
    }
    // create post
    else if (event["httpMethod"]==="POST" && event["path"].includes("createPost")){
      const { location, imageUrl, content, title, tags } = JSON.parse(event['body']);
      const { userId } = event['pathParameters'];
      // const { username: authorname } = data.user;
      const res = await pool.query(
        "INSERT INTO posts (dateTime, title, location, imageUrl, userId, content, tags) VALUES (to_timestamp($1),$2,$3,$4,$5,$6,$7) RETURNING *",
        [
          Date.now() / 1000.0,
          title,
          location,
          imageUrl,
          userId,
          content,
          // authorname,
          tags,
        ]
      );
     result = res.rows[0];
    }

    // delete post
    else if (event["httpMethod"]==="DELETE"){
      const {postId, userId} = event["pathParameters"];
      await pool.query("DELETE FROM posts WHERE id = $1 AND userid = $2", [
        postId,
        userId,
      ]);
      result = {postId,userId}
    }
    else {
      throw new Error("invalid request");
    }
    // how to do check save status? How to get current user?
    /*
    const userId = req.user?.id;
    const { id } = req.params;
    if (userId) {
      const status = await Post.checkSaveStatus(id, userId);
      req.saveStatus = status;
    }
    */
    // if (userId != undefined) {
    //   const res = await pool.query(
    //     `SELECT id, dateTime, title, content, location, imageurl, numoflikes, numofcomments, authorname, posts.userid, tags, likes.val 
    //      FROM posts 
    //      LEFT JOIN likes ON likes.postId = posts.id AND likes.userId = $2 
    //      WHERE posts.id = $1`,
    //     [postId, userId]
    //   );
    //   result = res.rows[0];
    // }
    

    // Commit the transaction to save the changes to the database
    await pool.query('COMMIT');

    // Return the result as a JSON response
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json','Access-Control-Allow-Origin':'*' },
      body: JSON.stringify(result)
    };
  } catch (error) {
    // Roll back the transaction if an error occurs
    await pool.query('ROLLBACK');

    // Return the error message as a JSON response
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  } finally {
    // Release the client from the connection pool
    pool.end();
  }
};
