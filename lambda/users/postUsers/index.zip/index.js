const { Pool } = require('pg');

exports.handler = async (event, context) => {
  // Define your PostgreSQL database credentials
  const dbConfig = {
    user: process.env.user,
    host: process.env.write,
    database: process.env.database,
    password: process.env.password,
    port: process.env.port
  };

  // Create a connection pool to the PostgreSQL database
  const pool = new Pool(dbConfig);

  try {
    // Use a transaction to execute multiple SQL queries together
    await pool.query('BEGIN');

    // Determine whether to fetch data or write data based on the event input
    let result;
      
    // Extract the user data from the request body
    const { username, hashed, fname, lname, dobFinal, email, profileUrl } = event;
    // result = event;
    // Define the SQL query to insert the user data into the database
    const insertQuery = 'INSERT INTO users (username, password, fname, lname, dob, email, joinDate, profilephoto) VALUES ($1, $2, $3, $4, $5, $6, to_timestamp($7), $8)';

    // Execute the SQL query to insert the user data into the database
    const values = [
      username,
      hashed,
      fname,
      lname,
      dobFinal,
      email,
      Date.now() / 1000.0,
      profileUrl,
    ];
    await pool.query(insertQuery, values);

    result = { message: 'User data inserted successfully' };
    

    // Commit the transaction to save the changes to the database
    await pool.query('COMMIT');

    // Return the result as a JSON response
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: result
    };
  } catch (error) {
    // Roll back the transaction if an error occurs
    await pool.query('ROLLBACK');

    // Return the error message as a JSON response
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  } finally {
    // Release the client from the connection pool
    pool.end();
  }
};
